#include <concepts>
#include <iostream>

template <typename T>
concept Addable = requires(T a, T b) {
    a + b; // Ensure that T supports the addition operator
};

Addable auto add(Addable auto a, Addable auto b) {
    return a + b;
}

int main() {
    std::cout << add(2, 3) << std::endl;  // Works with types that support addition
    return 0;
}